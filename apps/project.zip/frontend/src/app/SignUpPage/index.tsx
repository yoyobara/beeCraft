export { SignUpPage } from './SignUpPage';
